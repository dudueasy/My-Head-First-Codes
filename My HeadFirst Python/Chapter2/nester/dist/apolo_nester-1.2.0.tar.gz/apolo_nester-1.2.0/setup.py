from distutils.core import setup

setup(
        name = 'apolo_nester',
        version = '1.2.0',
        py_modules =['apolo_nester'],
        author = 'Apolo_Du',
        author_email= 'dudueasy@126.com',
        url='http://www.apolodu.xyz',
        description = 'A printer of nested lists',
)
